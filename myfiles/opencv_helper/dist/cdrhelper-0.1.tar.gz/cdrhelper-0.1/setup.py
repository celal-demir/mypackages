from setuptools import setup, find_packages

setup(
    name='cdrhelper',
    version='0.1',
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'cdrhelper':['fonts/*.ttf'],
    },
    install_requires=[
        'opencv-python',
        'pillow',
        'matplotlib',
    ],
    author='CDR',
)