import os.path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import pathlib
import math
import matplotlib.pyplot as plt

root = pathlib.Path(__file__).parent


def get_font_by_name(font_name, font_size):
    font_dir = root.joinpath('fonts')
    font_path = font_dir.joinpath(font_name + ".ttf")
    if not font_path.exists():
        raise NameError(f"Not found {font_name}.ttf")
    return ImageFont.truetype(font_path, font_size)


def get_text_coord(draw, text, font, img_width, title_height):
    bbox = draw.textbbox((0, 0), text, font=font)
    bbox_left = bbox[0]
    bbox_top = bbox[1]
    bbox_right = bbox[2]
    bbox_bottom = bbox[3]

    text_width = bbox_right - bbox_left
    text_height = bbox_bottom - bbox_top

    text_x = (img_width - text_width) // 2
    text_y = (title_height - text_height) // 2 - bbox_top
    return text_x, text_y


def create_title(title, img_width, title_height, title_color, title_font_size, font, title_text_color):
    title_image = Image.new('RGB', (img_width, title_height), color=title_color)
    draw = ImageDraw.Draw(title_image)
    text_x, text_y = get_text_coord(draw, title, font, img_width, title_height)
    draw.text((text_x, text_y), text=title, font=font, fill=title_text_color)
    title = cv2.cvtColor(np.array(title_image), cv2.COLOR_BGR2RGB)
    return title


def img_with_title(images, titles, img_width, img_height, title_height, title_color, title_font_size, font,
                   title_text_color):
    merge_list = []
    for image, title in zip(images, titles):
        if image.ndim == 2:
            image = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
        image_title = create_title(title, img_width, title_height, title_color, title_font_size, font, title_text_color)
        image = cv2.resize(image, (img_width, img_height))
        merge = np.vstack((image_title, image))
        merge_list.append(merge)
    return merge_list


def create_background(image_count, img_width, img_height, title_height, space, nrows, bg_color):
    ncols = image_count / nrows
    bg_width = int(img_width * ncols + (space * (ncols + 1)))
    bg_height = int(img_height * nrows + (space * (nrows + 1)) + nrows * title_height)
    background = np.zeros((bg_height, bg_width, 3), dtype=np.uint8)
    background[:] = bg_color
    background = cv2.cvtColor(background, cv2.COLOR_BGR2RGB)
    return background


def merge_with_opencv(images, titles, img_width=300, img_height=300, space=10, title_height=40, nrows=1,
                      title_color=(34, 42, 53), title_font_size=28, font='BungeeTint', title_text_color='white',
                      bg_color=(255, 255, 255)):
    font = get_font_by_name(font, title_font_size)
    images_with_title = img_with_title(images, titles, img_width, img_height, title_height, title_color,
                                       title_font_size, font, title_text_color)
    width = images_with_title[0].shape[1]
    height = images_with_title[0].shape[0]
    if not (len(images) / nrows).is_integer():
        s = np.zeros((height, width, 3), np.uint8)
        s[:, :] = (255, 255, 255)
        images_with_title.append(s)
    column_count = len(images_with_title) // nrows
    bg = create_background(len(images_with_title), img_width, img_height, title_height, space, nrows, bg_color)
    img_id = 0
    for row in range(nrows):
        for column in range(column_count):
            start_x = (column * width) + ((column + 1) * space)
            end_x = start_x + width
            start_y = (row * height) + ((row + 1) * space)
            end_y = start_y + height
            bg[start_y:end_y, start_x:end_x] = images_with_title[img_id]
            img_id += 1
    return bg


def fig2cv(fig):
    fig.canvas.draw()
    image = np.frombuffer(fig.canvas.buffer_rgba(), dtype=np.uint8)
    width, height = fig.canvas.get_width_height()
    img = image.reshape((height, width, 4))
    return cv2.cvtColor(img, cv2.COLOR_BGRA2RGB)


def merge_with_matplotlib(images, titles, fig_size=(10, 6), title=None, fontSize=15, titleColor="green", n_rows=1):
    n_cols = math.ceil(len(images) / n_rows)
    fig, axes = plt.subplots(n_rows, n_cols, figsize=fig_size)

    if title:
        fig.suptitle(title, fontsize=20, fontweight='bold', fontname='Roboto')
    r = len(images) // n_rows
    img_id = 0
    for row_num in range(n_rows):
        for col_num in range(n_cols):
            if n_rows == 1:
                ax = axes[col_num]
            else:
                ax = axes[row_num][col_num]
            try:
                img = cv2.cvtColor(images[img_id], cv2.COLOR_BGR2RGB)
                ax.imshow(img)
                t = f"{titles[img_id]}"
                ax.text(0.5, 1.1, t, fontsize=float(fontSize), fontfamily='Manrope', transform=ax.transAxes,
                        ha='center', va='center',
                        bbox=dict(facecolor=titleColor, alpha=0.2, edgecolor='black', boxstyle='round,pad=0.2'))
            except IndexError:
                ax.axis('off')
                print("No image available")
            img_id += 1
    fig.tight_layout()
    return fig2cv(fig)


def draw_arrowed(img, start, end, color, thickness, lineType, arrow_length, angle ):
    arrow_length = thickness + arrow_length
    angle = angle * (math.pi / 180)

    x1 = start[0]
    x2 = end[0]
    y1 = start[1]
    y2 = end[1]

    line_angle = math.atan2(y2 - y1, x2 - x1)

    p1 = (
        int(x2 - arrow_length * math.cos(line_angle - angle)),
        int(y2 - arrow_length * math.sin(line_angle - angle))
    )
    p2 = (
        int(x2 - arrow_length * math.cos(line_angle + angle)),
        int(y2 - arrow_length * math.sin(line_angle + angle))
    )
    # cv2.circle(img, p1, 5, (255,0 ,0),-1)
    points = np.array([end, p1, p2])
    cv2.fillPoly(img, [points], color, lineType)

    line_end_x = (p1[0] + p2[0]) // 2
    line_end_y = (p1[1] + p2[1]) // 2
    line_end = (line_end_x, line_end_y)
    return line_end


def draw_arrowed_line(img, start, end, color, thickness, lineType=cv2.LINE_AA, direction=2, arrow_lenght=10, angle=30):
    end = draw_arrowed(img, start, end, color, thickness, lineType, arrow_lenght, angle)
    if direction == 2:
        start = draw_arrowed(img, end, start, color, thickness, lineType, arrow_lenght, angle)
    print(start, end)
    cv2.line(img, start, end, color, thickness, lineType)



